<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function Dashboard(){
        return view('admin.DashboardPage');
    }
    public function Blood_Request(){
        return view('admin.BloodRequestPage');
    }
    public function Donor_list(){
        return view('admin.DonorListPage');
    }
    public function Complete_lists(){
        return view('admin.CompleteBloodRequest');
    }
    
}
