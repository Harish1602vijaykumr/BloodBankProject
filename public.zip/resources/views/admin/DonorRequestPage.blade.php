@extends('admin.admin_layout')
@section('content')
         <div class="content-space">
                <h1>Donor Request</h1>
                <table class="table">
                     <thead>
                            <tr class="tr">
                                   <th class="line">Donor Name</th>
                                   <th class="line">Donor dob</th>
                                   <th class="line">Bloodgroup</th>
                                   <th class="line">Gender</th>
                                   <th class="line">Mobile</th>
                                   <th class="line">District id</th>
                                   <th class="line">Address</th>
                                   
                            </tr>
                     </thead>
                     <tbody>
                            @foreach($donor as $donor)
                            <tr class="tr">
                                   <td class="line">{{$donor->donor_name}}</td>
                                   <td class="line">{{$donor->donor_code}}</td>
                                   <td class="line">{{$donor->bloodgroup}}</td>
                                   <td class="line">{{$donor->gender}}</td>
                                   <td class="line">{{$donor->mobile_no}}</td>
                                   <td class="line">{{$donor->district_id}}</td>
                                   <td class="line">{{$donor->address}}</td>
                                   <td class="line">
                                          <img src="{{asset('public/image/')}}/{{$donor['image']}}" alt="" height="50px" width="50px
                                          ">
                                   </td>

                                  
                            </tr>
                            @endforeach
                     </tbody>
               </table>
         </div>
@endsection              
 