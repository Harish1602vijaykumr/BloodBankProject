@extends('admin.admin_layout')
@section('content')
         <div class="content-space">
                <h1>Complete Blood Request<h1>
         </div>
@endsection              
 