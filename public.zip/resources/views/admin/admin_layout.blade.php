<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="{{asset('public/css/style.css')}}">
</head>
<body>
    <div>
       
         <div>
            <nav>
                <h1>Blood Bank</h1>
            </nav>
         </div>
         
         <div class="sidenav">
            <a href="{{url('/dashboard_page')}}">Dashboard</a>
            <a href="{{url('/districts_page')}}">Districts</a>
            <a href="{{url('/donor_page')}}">donor request</a>
            <a href="{{url('/donor_list_page')}}">Donor Listing</a>
            <a href="{{url('/blood_page')}}">Blood Request</a>
            <a href="{{url('/complete_page')}}">Complete B.request</a>
            <a href="{{url('/signout')}}">Logout</a>
         </div>
        @yield('content')
    </div>
</body>
</html>