@extends('admin.admin_layout')
@section('content')
         <div class="content-space">
                <h1>dashbord</h1>
         </div>
@endsection              
 