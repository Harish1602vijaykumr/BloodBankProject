@extends('admin.admin_layout')
@section('content')
         <div class="content-space">
                <h1>Blood Request Page</h1>
         </div>
@endsection              
 