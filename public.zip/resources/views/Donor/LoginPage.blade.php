<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/login.css')}}">

</head>
<body>
				
              
	<div class="container">
		<h1>Blood Bank</h1>

		<label>Email :</label>
		<input type="email" name="user-email" id="email" class="email"><br/>

		<label>Password :</label>
		<input type="password" name="user-password" id="password" class="password"><br/>

		<button type="submit" id="login">Login</button>
	</div>

</body>
</html>