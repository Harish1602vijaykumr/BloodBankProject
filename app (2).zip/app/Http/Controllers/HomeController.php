<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    
    public function index()
    {
        return view('admin.DashboardPage');
    }
    public function Login(){
        return view('auth.login');
    }
    public function Navbar(){
        return view('donor.navbar');
    }
    public function Landing(){
        return view('donor.LandingPage');
    }
   
}
