<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class blood extends Model
{
    use HasFactory;
    protected $table ="bloodrequest";
    protected $primaryKey ="id"; 
}
